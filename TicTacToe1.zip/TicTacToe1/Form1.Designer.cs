﻿namespace TicTacToe1
{
    partial class TicTacToe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SplitContainer = new System.Windows.Forms.SplitContainer();
            this.Board = new System.Windows.Forms.TableLayoutPanel();
            this.space9 = new System.Windows.Forms.Button();
            this.space8 = new System.Windows.Forms.Button();
            this.space7 = new System.Windows.Forms.Button();
            this.space6 = new System.Windows.Forms.Button();
            this.space5 = new System.Windows.Forms.Button();
            this.space4 = new System.Windows.Forms.Button();
            this.space3 = new System.Windows.Forms.Button();
            this.space2 = new System.Windows.Forms.Button();
            this.space1 = new System.Windows.Forms.Button();
            this.BottomFrame = new System.Windows.Forms.TableLayoutPanel();
            this.Player1Label = new System.Windows.Forms.Label();
            this.GameplayButtonsFrame = new System.Windows.Forms.TableLayoutPanel();
            this.btnGoodbye = new System.Windows.Forms.Button();
            this.btnRestart = new System.Windows.Forms.Button();
            this.btnNewPlayer = new System.Windows.Forms.Button();
            this.WelcomeMessage = new System.Windows.Forms.Label();
            this.Player2Label = new System.Windows.Forms.Label();
            this.Player1Name = new System.Windows.Forms.Label();
            this.LabelPromptingName = new System.Windows.Forms.Label();
            this.Player2Name = new System.Windows.Forms.Label();
            this.P1Wins = new System.Windows.Forms.Label();
            this.P2Wins = new System.Windows.Forms.Label();
            this.P1Losses = new System.Windows.Forms.Label();
            this.MessageSpace1 = new System.Windows.Forms.Label();
            this.P2Losses = new System.Windows.Forms.Label();
            this.P1Draws = new System.Windows.Forms.Label();
            this.MessageSpace2 = new System.Windows.Forms.Label();
            this.P2Draws = new System.Windows.Forms.Label();
            this.EnterNameBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.SplitContainer)).BeginInit();
            this.SplitContainer.Panel1.SuspendLayout();
            this.SplitContainer.Panel2.SuspendLayout();
            this.SplitContainer.SuspendLayout();
            this.Board.SuspendLayout();
            this.BottomFrame.SuspendLayout();
            this.GameplayButtonsFrame.SuspendLayout();
            this.SuspendLayout();
            // 
            // SplitContainer
            // 
            this.SplitContainer.BackColor = System.Drawing.Color.Transparent;
            this.SplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SplitContainer.Location = new System.Drawing.Point(0, 0);
            this.SplitContainer.Name = "SplitContainer";
            this.SplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // SplitContainer.Panel1
            // 
            this.SplitContainer.Panel1.Controls.Add(this.Board);
            // 
            // SplitContainer.Panel2
            // 
            this.SplitContainer.Panel2.BackColor = System.Drawing.Color.Transparent;
            this.SplitContainer.Panel2.Controls.Add(this.BottomFrame);
            this.SplitContainer.Panel2.Controls.Add(this.GameplayButtonsFrame);
            this.SplitContainer.Panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer1_Panel2_Paint);
            this.SplitContainer.Size = new System.Drawing.Size(701, 1044);
            this.SplitContainer.SplitterDistance = 654;
            this.SplitContainer.TabIndex = 0;
            // 
            // Board
            // 
            this.Board.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.Board.ColumnCount = 3;
            this.Board.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.Board.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.Board.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.Board.Controls.Add(this.space9, 2, 2);
            this.Board.Controls.Add(this.space8, 1, 2);
            this.Board.Controls.Add(this.space7, 0, 2);
            this.Board.Controls.Add(this.space6, 2, 1);
            this.Board.Controls.Add(this.space5, 1, 1);
            this.Board.Controls.Add(this.space4, 0, 1);
            this.Board.Controls.Add(this.space3, 2, 0);
            this.Board.Controls.Add(this.space2, 1, 0);
            this.Board.Controls.Add(this.space1, 0, 0);
            this.Board.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Board.Location = new System.Drawing.Point(0, 0);
            this.Board.Name = "Board";
            this.Board.RowCount = 3;
            this.Board.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.Board.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.Board.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.Board.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.Board.Size = new System.Drawing.Size(701, 654);
            this.Board.TabIndex = 0;
            this.Board.Paint += new System.Windows.Forms.PaintEventHandler(this.Board_Paint);
            // 
            // space9
            // 
            this.space9.BackColor = System.Drawing.SystemColors.GrayText;
            this.space9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.space9.Font = new System.Drawing.Font("Arial Black", 48F, System.Drawing.FontStyle.Bold);
            this.space9.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.space9.Location = new System.Drawing.Point(466, 436);
            this.space9.Margin = new System.Windows.Forms.Padding(0);
            this.space9.Name = "space9";
            this.space9.Size = new System.Drawing.Size(235, 218);
            this.space9.TabIndex = 8;
            this.space9.Text = "O";
            this.space9.UseVisualStyleBackColor = false;
            // 
            // space8
            // 
            this.space8.BackColor = System.Drawing.SystemColors.GrayText;
            this.space8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.space8.Font = new System.Drawing.Font("Arial Black", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.space8.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.space8.Location = new System.Drawing.Point(233, 436);
            this.space8.Margin = new System.Windows.Forms.Padding(0);
            this.space8.Name = "space8";
            this.space8.Size = new System.Drawing.Size(233, 218);
            this.space8.TabIndex = 7;
            this.space8.Text = "X";
            this.space8.UseVisualStyleBackColor = false;
            // 
            // space7
            // 
            this.space7.BackColor = System.Drawing.SystemColors.GrayText;
            this.space7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.space7.Font = new System.Drawing.Font("Arial Black", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.space7.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.space7.Location = new System.Drawing.Point(0, 436);
            this.space7.Margin = new System.Windows.Forms.Padding(0);
            this.space7.Name = "space7";
            this.space7.Size = new System.Drawing.Size(233, 218);
            this.space7.TabIndex = 6;
            this.space7.Text = "X";
            this.space7.UseVisualStyleBackColor = false;
            // 
            // space6
            // 
            this.space6.BackColor = System.Drawing.SystemColors.GrayText;
            this.space6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.space6.Font = new System.Drawing.Font("Arial Black", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.space6.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.space6.Location = new System.Drawing.Point(466, 218);
            this.space6.Margin = new System.Windows.Forms.Padding(0);
            this.space6.Name = "space6";
            this.space6.Size = new System.Drawing.Size(235, 218);
            this.space6.TabIndex = 5;
            this.space6.Text = "X";
            this.space6.UseVisualStyleBackColor = false;
            // 
            // space5
            // 
            this.space5.BackColor = System.Drawing.SystemColors.GrayText;
            this.space5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.space5.Font = new System.Drawing.Font("Arial Black", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.space5.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.space5.Location = new System.Drawing.Point(233, 218);
            this.space5.Margin = new System.Windows.Forms.Padding(0);
            this.space5.Name = "space5";
            this.space5.Size = new System.Drawing.Size(233, 218);
            this.space5.TabIndex = 4;
            this.space5.Text = "O";
            this.space5.UseVisualStyleBackColor = false;
            // 
            // space4
            // 
            this.space4.BackColor = System.Drawing.SystemColors.GrayText;
            this.space4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.space4.Font = new System.Drawing.Font("Arial Black", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.space4.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.space4.Location = new System.Drawing.Point(0, 218);
            this.space4.Margin = new System.Windows.Forms.Padding(0);
            this.space4.Name = "space4";
            this.space4.Size = new System.Drawing.Size(233, 218);
            this.space4.TabIndex = 3;
            this.space4.Text = "O";
            this.space4.UseVisualStyleBackColor = false;
            this.space4.Click += new System.EventHandler(this.space4_Click);
            // 
            // space3
            // 
            this.space3.BackColor = System.Drawing.SystemColors.GrayText;
            this.space3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.space3.Font = new System.Drawing.Font("Arial Black", 48F);
            this.space3.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.space3.Location = new System.Drawing.Point(466, 0);
            this.space3.Margin = new System.Windows.Forms.Padding(0);
            this.space3.Name = "space3";
            this.space3.Size = new System.Drawing.Size(235, 218);
            this.space3.TabIndex = 2;
            this.space3.Text = "O";
            this.space3.UseVisualStyleBackColor = false;
            this.space3.Click += new System.EventHandler(this.space3_Click);
            // 
            // space2
            // 
            this.space2.BackColor = System.Drawing.SystemColors.GrayText;
            this.space2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.space2.Font = new System.Drawing.Font("Arial Black", 48F);
            this.space2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.space2.Location = new System.Drawing.Point(233, 0);
            this.space2.Margin = new System.Windows.Forms.Padding(0);
            this.space2.Name = "space2";
            this.space2.Size = new System.Drawing.Size(233, 218);
            this.space2.TabIndex = 1;
            this.space2.Text = "X";
            this.space2.UseVisualStyleBackColor = false;
            this.space2.Click += new System.EventHandler(this.space2_Click);
            // 
            // space1
            // 
            this.space1.BackColor = System.Drawing.SystemColors.GrayText;
            this.space1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.space1.Font = new System.Drawing.Font("Arial Black", 48F);
            this.space1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.space1.Location = new System.Drawing.Point(0, 0);
            this.space1.Margin = new System.Windows.Forms.Padding(0);
            this.space1.Name = "space1";
            this.space1.Size = new System.Drawing.Size(233, 218);
            this.space1.TabIndex = 0;
            this.space1.Text = "X";
            this.space1.UseVisualStyleBackColor = false;
            this.space1.Click += new System.EventHandler(this.space1_Click);
            // 
            // BottomFrame
            // 
            this.BottomFrame.BackColor = System.Drawing.Color.Transparent;
            this.BottomFrame.ColumnCount = 3;
            this.BottomFrame.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.BottomFrame.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.BottomFrame.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.BottomFrame.Controls.Add(this.P2Draws, 2, 4);
            this.BottomFrame.Controls.Add(this.MessageSpace2, 1, 4);
            this.BottomFrame.Controls.Add(this.P1Draws, 0, 4);
            this.BottomFrame.Controls.Add(this.P2Losses, 2, 3);
            this.BottomFrame.Controls.Add(this.MessageSpace1, 1, 3);
            this.BottomFrame.Controls.Add(this.P1Losses, 0, 3);
            this.BottomFrame.Controls.Add(this.P2Wins, 2, 2);
            this.BottomFrame.Controls.Add(this.P1Wins, 0, 2);
            this.BottomFrame.Controls.Add(this.Player2Name, 2, 1);
            this.BottomFrame.Controls.Add(this.LabelPromptingName, 1, 1);
            this.BottomFrame.Controls.Add(this.Player1Name, 0, 1);
            this.BottomFrame.Controls.Add(this.Player2Label, 2, 0);
            this.BottomFrame.Controls.Add(this.WelcomeMessage, 1, 0);
            this.BottomFrame.Controls.Add(this.Player1Label, 0, 0);
            this.BottomFrame.Controls.Add(this.EnterNameBox, 1, 2);
            this.BottomFrame.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.BottomFrame.GrowStyle = System.Windows.Forms.TableLayoutPanelGrowStyle.FixedSize;
            this.BottomFrame.Location = new System.Drawing.Point(0, 96);
            this.BottomFrame.Name = "BottomFrame";
            this.BottomFrame.RowCount = 5;
            this.BottomFrame.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.BottomFrame.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.BottomFrame.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.BottomFrame.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.BottomFrame.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.BottomFrame.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.BottomFrame.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.BottomFrame.Size = new System.Drawing.Size(701, 290);
            this.BottomFrame.TabIndex = 2;
            this.BottomFrame.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // Player1Label
            // 
            this.Player1Label.AutoSize = true;
            this.Player1Label.BackColor = System.Drawing.Color.BlueViolet;
            this.Player1Label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Player1Label.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Player1Label.Font = new System.Drawing.Font("Cascadia Code", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Player1Label.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Player1Label.Location = new System.Drawing.Point(3, 3);
            this.Player1Label.Margin = new System.Windows.Forms.Padding(3);
            this.Player1Label.Name = "Player1Label";
            this.Player1Label.Size = new System.Drawing.Size(169, 52);
            this.Player1Label.TabIndex = 0;
            this.Player1Label.Text = "PLAYER 1";
            this.Player1Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Player1Label.Click += new System.EventHandler(this.label1_Click_2);
            // 
            // GameplayButtonsFrame
            // 
            this.GameplayButtonsFrame.ColumnCount = 3;
            this.GameplayButtonsFrame.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.GameplayButtonsFrame.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.GameplayButtonsFrame.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.GameplayButtonsFrame.Controls.Add(this.btnGoodbye, 2, 0);
            this.GameplayButtonsFrame.Controls.Add(this.btnRestart, 1, 0);
            this.GameplayButtonsFrame.Controls.Add(this.btnNewPlayer, 0, 0);
            this.GameplayButtonsFrame.Dock = System.Windows.Forms.DockStyle.Top;
            this.GameplayButtonsFrame.Location = new System.Drawing.Point(0, 0);
            this.GameplayButtonsFrame.Name = "GameplayButtonsFrame";
            this.GameplayButtonsFrame.RowCount = 1;
            this.GameplayButtonsFrame.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.GameplayButtonsFrame.Size = new System.Drawing.Size(701, 96);
            this.GameplayButtonsFrame.TabIndex = 1;
            this.GameplayButtonsFrame.Paint += new System.Windows.Forms.PaintEventHandler(this.GameplayButtons_Paint);
            // 
            // btnGoodbye
            // 
            this.btnGoodbye.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnGoodbye.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnGoodbye.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGoodbye.Font = new System.Drawing.Font("Cascadia Code", 11F);
            this.btnGoodbye.Location = new System.Drawing.Point(476, 10);
            this.btnGoodbye.Margin = new System.Windows.Forms.Padding(10);
            this.btnGoodbye.Name = "btnGoodbye";
            this.btnGoodbye.Size = new System.Drawing.Size(215, 76);
            this.btnGoodbye.TabIndex = 2;
            this.btnGoodbye.Text = "End Game";
            this.btnGoodbye.UseVisualStyleBackColor = false;
            // 
            // btnRestart
            // 
            this.btnRestart.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnRestart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnRestart.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRestart.Font = new System.Drawing.Font("Cascadia Code", 11F);
            this.btnRestart.Location = new System.Drawing.Point(243, 10);
            this.btnRestart.Margin = new System.Windows.Forms.Padding(10);
            this.btnRestart.Name = "btnRestart";
            this.btnRestart.Size = new System.Drawing.Size(213, 76);
            this.btnRestart.TabIndex = 1;
            this.btnRestart.Text = "Restart Game";
            this.btnRestart.UseVisualStyleBackColor = false;
            this.btnRestart.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnNewPlayer
            // 
            this.btnNewPlayer.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnNewPlayer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnNewPlayer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNewPlayer.Font = new System.Drawing.Font("Cascadia Code", 11F);
            this.btnNewPlayer.Location = new System.Drawing.Point(10, 10);
            this.btnNewPlayer.Margin = new System.Windows.Forms.Padding(10);
            this.btnNewPlayer.Name = "btnNewPlayer";
            this.btnNewPlayer.Size = new System.Drawing.Size(213, 76);
            this.btnNewPlayer.TabIndex = 0;
            this.btnNewPlayer.Text = "New Player";
            this.btnNewPlayer.UseVisualStyleBackColor = false;
            this.btnNewPlayer.Click += new System.EventHandler(this.button1_Click);
            // 
            // WelcomeMessage
            // 
            this.WelcomeMessage.AutoSize = true;
            this.WelcomeMessage.BackColor = System.Drawing.Color.LightSteelBlue;
            this.WelcomeMessage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.WelcomeMessage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.WelcomeMessage.Font = new System.Drawing.Font("Cascadia Code", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WelcomeMessage.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.WelcomeMessage.Location = new System.Drawing.Point(178, 3);
            this.WelcomeMessage.Margin = new System.Windows.Forms.Padding(3);
            this.WelcomeMessage.Name = "WelcomeMessage";
            this.WelcomeMessage.Size = new System.Drawing.Size(344, 52);
            this.WelcomeMessage.TabIndex = 1;
            this.WelcomeMessage.Text = "WELCOME TO TIC TAC TOE";
            this.WelcomeMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.WelcomeMessage.Click += new System.EventHandler(this.label2_Click);
            // 
            // Player2Label
            // 
            this.Player2Label.AutoSize = true;
            this.Player2Label.BackColor = System.Drawing.Color.Gold;
            this.Player2Label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Player2Label.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Player2Label.Font = new System.Drawing.Font("Cascadia Code", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Player2Label.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Player2Label.Location = new System.Drawing.Point(528, 3);
            this.Player2Label.Margin = new System.Windows.Forms.Padding(3);
            this.Player2Label.Name = "Player2Label";
            this.Player2Label.Size = new System.Drawing.Size(170, 52);
            this.Player2Label.TabIndex = 2;
            this.Player2Label.Text = "PLAYER 2";
            this.Player2Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Player1Name
            // 
            this.Player1Name.AutoSize = true;
            this.Player1Name.BackColor = System.Drawing.Color.Transparent;
            this.Player1Name.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Player1Name.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Player1Name.Font = new System.Drawing.Font("Cascadia Code", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Player1Name.ForeColor = System.Drawing.Color.BlueViolet;
            this.Player1Name.Location = new System.Drawing.Point(3, 61);
            this.Player1Name.Margin = new System.Windows.Forms.Padding(3);
            this.Player1Name.Name = "Player1Name";
            this.Player1Name.Size = new System.Drawing.Size(169, 52);
            this.Player1Name.TabIndex = 3;
            this.Player1Name.Text = "Computer";
            this.Player1Name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Player1Name.Click += new System.EventHandler(this.SpaceForPlayer1Name_Click);
            // 
            // LabelPromptingName
            // 
            this.LabelPromptingName.AutoSize = true;
            this.LabelPromptingName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LabelPromptingName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LabelPromptingName.Font = new System.Drawing.Font("Cascadia Code", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelPromptingName.ForeColor = System.Drawing.Color.Black;
            this.LabelPromptingName.Location = new System.Drawing.Point(178, 61);
            this.LabelPromptingName.Margin = new System.Windows.Forms.Padding(3);
            this.LabelPromptingName.Name = "LabelPromptingName";
            this.LabelPromptingName.Size = new System.Drawing.Size(344, 52);
            this.LabelPromptingName.TabIndex = 4;
            this.LabelPromptingName.Text = "Please enter your name: ";
            this.LabelPromptingName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Player2Name
            // 
            this.Player2Name.AutoSize = true;
            this.Player2Name.BackColor = System.Drawing.Color.Transparent;
            this.Player2Name.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Player2Name.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Player2Name.Font = new System.Drawing.Font("Cascadia Code", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Player2Name.ForeColor = System.Drawing.Color.Gold;
            this.Player2Name.Location = new System.Drawing.Point(528, 61);
            this.Player2Name.Margin = new System.Windows.Forms.Padding(3);
            this.Player2Name.Name = "Player2Name";
            this.Player2Name.Size = new System.Drawing.Size(170, 52);
            this.Player2Name.TabIndex = 5;
            this.Player2Name.Text = "Tim";
            this.Player2Name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Player2Name.Click += new System.EventHandler(this.Player2Name_Click);
            // 
            // P1Wins
            // 
            this.P1Wins.AutoSize = true;
            this.P1Wins.BackColor = System.Drawing.Color.Transparent;
            this.P1Wins.Dock = System.Windows.Forms.DockStyle.Fill;
            this.P1Wins.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P1Wins.Font = new System.Drawing.Font("Cascadia Code", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.P1Wins.ForeColor = System.Drawing.SystemColors.ControlText;
            this.P1Wins.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.P1Wins.Location = new System.Drawing.Point(3, 119);
            this.P1Wins.Margin = new System.Windows.Forms.Padding(3);
            this.P1Wins.Name = "P1Wins";
            this.P1Wins.Padding = new System.Windows.Forms.Padding(0, 0, 50, 0);
            this.P1Wins.Size = new System.Drawing.Size(169, 52);
            this.P1Wins.TabIndex = 6;
            this.P1Wins.Text = "WINS:";
            this.P1Wins.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // P2Wins
            // 
            this.P2Wins.AutoSize = true;
            this.P2Wins.BackColor = System.Drawing.Color.Transparent;
            this.P2Wins.Dock = System.Windows.Forms.DockStyle.Fill;
            this.P2Wins.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P2Wins.Font = new System.Drawing.Font("Cascadia Code", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.P2Wins.ForeColor = System.Drawing.SystemColors.ControlText;
            this.P2Wins.Location = new System.Drawing.Point(528, 119);
            this.P2Wins.Margin = new System.Windows.Forms.Padding(3);
            this.P2Wins.Name = "P2Wins";
            this.P2Wins.Padding = new System.Windows.Forms.Padding(0, 0, 50, 0);
            this.P2Wins.Size = new System.Drawing.Size(170, 52);
            this.P2Wins.TabIndex = 8;
            this.P2Wins.Text = "WINS:";
            this.P2Wins.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.P2Wins.Click += new System.EventHandler(this.P2Wins_Click);
            // 
            // P1Losses
            // 
            this.P1Losses.AutoSize = true;
            this.P1Losses.BackColor = System.Drawing.Color.Transparent;
            this.P1Losses.Dock = System.Windows.Forms.DockStyle.Fill;
            this.P1Losses.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P1Losses.Font = new System.Drawing.Font("Cascadia Code", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.P1Losses.ForeColor = System.Drawing.SystemColors.ControlText;
            this.P1Losses.Location = new System.Drawing.Point(3, 177);
            this.P1Losses.Margin = new System.Windows.Forms.Padding(3);
            this.P1Losses.Name = "P1Losses";
            this.P1Losses.Padding = new System.Windows.Forms.Padding(0, 0, 50, 0);
            this.P1Losses.Size = new System.Drawing.Size(169, 52);
            this.P1Losses.TabIndex = 9;
            this.P1Losses.Text = "LOSSES:";
            this.P1Losses.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MessageSpace1
            // 
            this.MessageSpace1.AutoSize = true;
            this.MessageSpace1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MessageSpace1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MessageSpace1.Font = new System.Drawing.Font("Cascadia Code", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MessageSpace1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.MessageSpace1.Location = new System.Drawing.Point(178, 177);
            this.MessageSpace1.Margin = new System.Windows.Forms.Padding(3);
            this.MessageSpace1.Name = "MessageSpace1";
            this.MessageSpace1.Size = new System.Drawing.Size(344, 52);
            this.MessageSpace1.TabIndex = 10;
            this.MessageSpace1.Text = "\"\"";
            this.MessageSpace1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.MessageSpace1.Click += new System.EventHandler(this.label11_Click);
            // 
            // P2Losses
            // 
            this.P2Losses.AutoSize = true;
            this.P2Losses.BackColor = System.Drawing.Color.Transparent;
            this.P2Losses.Dock = System.Windows.Forms.DockStyle.Fill;
            this.P2Losses.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P2Losses.Font = new System.Drawing.Font("Cascadia Code", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.P2Losses.ForeColor = System.Drawing.SystemColors.ControlText;
            this.P2Losses.Location = new System.Drawing.Point(528, 177);
            this.P2Losses.Margin = new System.Windows.Forms.Padding(3);
            this.P2Losses.Name = "P2Losses";
            this.P2Losses.Padding = new System.Windows.Forms.Padding(0, 0, 50, 0);
            this.P2Losses.Size = new System.Drawing.Size(170, 52);
            this.P2Losses.TabIndex = 11;
            this.P2Losses.Text = "LOSSES:";
            this.P2Losses.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // P1Draws
            // 
            this.P1Draws.AutoSize = true;
            this.P1Draws.BackColor = System.Drawing.Color.Transparent;
            this.P1Draws.Dock = System.Windows.Forms.DockStyle.Fill;
            this.P1Draws.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P1Draws.Font = new System.Drawing.Font("Cascadia Code", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.P1Draws.ForeColor = System.Drawing.SystemColors.ControlText;
            this.P1Draws.Location = new System.Drawing.Point(3, 235);
            this.P1Draws.Margin = new System.Windows.Forms.Padding(3);
            this.P1Draws.Name = "P1Draws";
            this.P1Draws.Padding = new System.Windows.Forms.Padding(0, 0, 50, 0);
            this.P1Draws.Size = new System.Drawing.Size(169, 52);
            this.P1Draws.TabIndex = 12;
            this.P1Draws.Text = "DRAWS:";
            this.P1Draws.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // MessageSpace2
            // 
            this.MessageSpace2.AutoSize = true;
            this.MessageSpace2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MessageSpace2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MessageSpace2.Font = new System.Drawing.Font("Cascadia Code", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MessageSpace2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.MessageSpace2.Location = new System.Drawing.Point(178, 235);
            this.MessageSpace2.Margin = new System.Windows.Forms.Padding(3);
            this.MessageSpace2.Name = "MessageSpace2";
            this.MessageSpace2.Size = new System.Drawing.Size(344, 52);
            this.MessageSpace2.TabIndex = 13;
            this.MessageSpace2.Text = "\"\"";
            this.MessageSpace2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // P2Draws
            // 
            this.P2Draws.AutoSize = true;
            this.P2Draws.BackColor = System.Drawing.Color.Transparent;
            this.P2Draws.Dock = System.Windows.Forms.DockStyle.Fill;
            this.P2Draws.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P2Draws.Font = new System.Drawing.Font("Cascadia Code", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.P2Draws.ForeColor = System.Drawing.SystemColors.ControlText;
            this.P2Draws.Location = new System.Drawing.Point(528, 235);
            this.P2Draws.Margin = new System.Windows.Forms.Padding(3);
            this.P2Draws.Name = "P2Draws";
            this.P2Draws.Padding = new System.Windows.Forms.Padding(0, 0, 50, 0);
            this.P2Draws.Size = new System.Drawing.Size(170, 52);
            this.P2Draws.TabIndex = 14;
            this.P2Draws.Text = "DRAWS:";
            this.P2Draws.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // EnterNameBox
            // 
            this.EnterNameBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.EnterNameBox.Font = new System.Drawing.Font("Cascadia Code", 12F);
            this.EnterNameBox.Location = new System.Drawing.Point(178, 119);
            this.EnterNameBox.Name = "EnterNameBox";
            this.EnterNameBox.Size = new System.Drawing.Size(344, 35);
            this.EnterNameBox.TabIndex = 15;
            this.EnterNameBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.EnterNameBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // TicTacToe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(701, 1044);
            this.Controls.Add(this.SplitContainer);
            this.MaximumSize = new System.Drawing.Size(1000, 1100);
            this.MinimumSize = new System.Drawing.Size(700, 1006);
            this.Name = "TicTacToe";
            this.Text = "TicTacToe";
            this.Load += new System.EventHandler(this.TicTacToe_Load);
            this.SplitContainer.Panel1.ResumeLayout(false);
            this.SplitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.SplitContainer)).EndInit();
            this.SplitContainer.ResumeLayout(false);
            this.Board.ResumeLayout(false);
            this.BottomFrame.ResumeLayout(false);
            this.BottomFrame.PerformLayout();
            this.GameplayButtonsFrame.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer SplitContainer;
        private System.Windows.Forms.TableLayoutPanel Board;
        private System.Windows.Forms.TableLayoutPanel GameplayButtonsFrame;
        private System.Windows.Forms.Button space1;
        private System.Windows.Forms.Button space9;
        private System.Windows.Forms.Button space8;
        private System.Windows.Forms.Button space7;
        private System.Windows.Forms.Button space6;
        private System.Windows.Forms.Button space5;
        private System.Windows.Forms.Button space4;
        private System.Windows.Forms.Button space3;
        private System.Windows.Forms.Button space2;
        private System.Windows.Forms.Button btnNewPlayer;
        private System.Windows.Forms.Button btnGoodbye;
        private System.Windows.Forms.Button btnRestart;
        private System.Windows.Forms.TableLayoutPanel BottomFrame;
        private System.Windows.Forms.Label Player1Label;
        private System.Windows.Forms.Label P2Draws;
        private System.Windows.Forms.Label MessageSpace2;
        private System.Windows.Forms.Label P1Draws;
        private System.Windows.Forms.Label P2Losses;
        private System.Windows.Forms.Label MessageSpace1;
        private System.Windows.Forms.Label P1Losses;
        private System.Windows.Forms.Label P2Wins;
        private System.Windows.Forms.Label P1Wins;
        private System.Windows.Forms.Label Player2Name;
        private System.Windows.Forms.Label LabelPromptingName;
        private System.Windows.Forms.Label Player1Name;
        private System.Windows.Forms.Label Player2Label;
        private System.Windows.Forms.Label WelcomeMessage;
        private System.Windows.Forms.TextBox EnterNameBox;
    }
}

